## My Library 

[Link To The Completed Project](https://my-librery-app.herokuapp.com/)

### My main focus while building this application was learning to use EJS .The website is not fully responsive. because i am not too good at styling things,and sometimes very lazy too.


