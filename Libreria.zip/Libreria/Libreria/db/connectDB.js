const mongoose = require('mongoose');
const dotenv = require('dotenv');
const connectDB = async () => {
    try {
        const conn = await mongoose.connect('mongodb://127.0.0.1/test',);
        
        console.log('mongoDB connected');
        return;
    } catch (err) {
        console.error('error while connecting to the database');
        console.log(err.message);
        process.exit(1);
    }


}
module.exports = connectDB;